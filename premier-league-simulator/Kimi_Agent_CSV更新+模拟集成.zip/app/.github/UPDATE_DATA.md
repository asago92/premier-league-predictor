# Updating the Simulation Data

This guide explains how to update the Premier League prediction simulation with new data.

## Quick Update

To update the simulation with new season data:

1. **Edit the CSV file**: Open `src/data/epl_data.csv`

2. **Add new season data**: Follow the existing format:
   ```csv
   Season,Rk,Squad,H-MP,H-W,H-D,H-L,H-GF,H-GA,H-GD,H-Pts,H-Pts/MP,A-MP,A-W,A-D,A-L,A-GF,A-GA,A-GD,A-Pts,A-Pts/MP
   2026 - 2027,1,Team Name,19,10,5,4,35,20,15,35,1.84,19,8,4,7,30,25,5,28,1.47
   ```

3. **Commit and push**: The simulation will automatically use the new data

## CSV Column Reference

| Column | Description |
|--------|-------------|
| `Season` | Season year (e.g., "2025 - 2026") |
| `Rk` | Final league rank |
| `Squad` | Team name |
| `H-MP` | Home matches played |
| `H-W` | Home wins |
| `H-D` | Home draws |
| `H-L` | Home losses |
| `H-GF` | Home goals for |
| `H-GA` | Home goals against |
| `H-GD` | Home goal difference |
| `H-Pts` | Home points |
| `H-Pts/MP` | Home points per match |
| `A-MP` | Away matches played |
| `A-W` | Away wins |
| `A-D` | Away draws |
| `A-L` | Away losses |
| `A-GF` | Away goals for |
| `A-GA` | Away goals against |
| `A-GD` | Away goal difference |
| `A-Pts` | Away points |
| `A-Pts/MP` | Away points per match |

## Data Sources

You can get this data from:
- [FBref](https://fbref.com/en/comps/9/Premier-League-Stats)
- [Premier League Official Site](https://www.premierleague.com/tables)
- [Transfermarkt](https://www.transfermarkt.com/premier-league/tabelle/wettbewerb/GB1)

## How It Works

The simulation uses:
1. **Historical attack/defense strength** - Calculated from goals scored/conceded
2. **Home/away performance** - Separate stats for home and away matches
3. **Poisson distribution** - For realistic goal scoring simulation
4. **Monte Carlo method** - Running 10,000+ simulations for accurate probabilities

## Team Name Mapping

The following team names are recognized:
- Arsenal
- Aston Villa
- Bournemouth
- Brentford
- Brighton
- Burnley
- Chelsea
- Crystal Palace
- Everton
- Fulham
- Liverpool
- Luton Town
- Manchester City
- Manchester United
- Newcastle United
- Nottingham Forest
- Sheffield United
- Tottenham
- West Ham
- Wolves

## Testing Your Changes

After updating the CSV:
1. Run `npm run dev` to start the development server
2. Check that teams appear with correct stats
3. Run simulations to verify predictions look reasonable

## Need Help?

Open an issue on GitHub if you need assistance updating the data.
